class RepositoryInterface:
    def translate(self, language: str, word: str) -> str:
        """translates word into given language"""
        pass
