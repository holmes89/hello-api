# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hello_api']

package_data = \
{'': ['*']}

install_requires = \
['fastapi>=0.81.0,<0.82.0',
 'redis>=4.3.4,<5.0.0',
 'redislite>=6.2.805324,<7.0.0',
 'requests>=2.28.1,<3.0.0',
 'uvicorn>=0.18.3,<0.19.0']

setup_kwargs = {
    'name': 'hello-api',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Joel Holmes',
    'author_email': 'holmes89@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
